###################
Under Developement Website
###################

ENHA Information System Management

*******************
Release Information
*******************

Initial Release

**************************
Changelog and New Features
**************************

Changelog :
V.01 : Native MVC
V.02 : Added CI Framework

